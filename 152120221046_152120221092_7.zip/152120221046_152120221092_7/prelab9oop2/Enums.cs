﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prelab9oop2
{
    public enum DifficultyLevel { Kolay = 0, Orta = 1, Zor = 2 }
    public enum Category { Tarih, Cografya, Matematik, GenelKültür, Karma }

    public class WordItem
    {
        public string Word { get; set; }
        public string Clue { get; set; }
    }
}
