﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace prelab9oop2
{
    public partial class SettingsForm : Form
    {
        public int GameSeconds { get; private set; }
        public DifficultyLevel Difficulty { get; private set; }
        public string SelectedBackground { get; private set; }  

        public SettingsForm(int currentSeconds, DifficultyLevel currentDiff)
        {
            InitializeComponent();

            // Süre ayarı
            nudSeconds.Minimum = 10;
            nudSeconds.Maximum = 300;
            nudSeconds.Value = currentSeconds;

            // Zorluk ayarı
            cbDifficulty.DropDownStyle = ComboBoxStyle.DropDownList;
            cbDifficulty.Items.Clear();
            cbDifficulty.Items.AddRange(new object[] { "Kolay", "Orta", "Zor" });
            cbDifficulty.SelectedIndex = (int)currentDiff;

            // --- Arka Plan Seçimi ---
            // 1) Oluşturma ve ekleme
            var cbBackground = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Size = new Size(120, 24),
                Anchor = AnchorStyles.None,
                Font = new Font("Arial", 14F, FontStyle.Regular)  // ← burası


            };
            cbBackground.Items.AddRange(new object[] { "Adam", "Papatya", "Balon" });
            cbBackground.SelectedIndex = 0;
            this.Controls.Add(cbBackground);
            
            btnOk.Text = "KAYDET";
            btnOk.Font = new Font("Arial", 14, FontStyle.Bold);
           
            


            btnOk.FlatStyle = FlatStyle.Flat;
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.BackColor = Color.Orange;
            btnOk.ForeColor = Color.Black;
            btnOk.MouseEnter += (s, e) => btnOk.BackColor = Color.DarkOrange;
            btnOk.MouseLeave += (s, e) => btnOk.BackColor = Color.Orange;

            // 2) Konumlandırma metodu
            void CenterControl(Control ctrl)
            {
                ctrl.Location = new Point(
                    (this.ClientSize.Width - ctrl.Width) / 2,
                    (this.ClientSize.Height - ctrl.Height) / 2
                );
            }

            // 3) İlk konumlandırma ve resize event’ine bağlama
            this.Load += (s, e) =>
            {
                CenterControl(cbBackground);
            };

            this.Resize += (s, e) =>
            {
                CenterControl(cbBackground);
            };


            // Tamam butonu
            btnOk.DialogResult = DialogResult.OK;
            btnOk.Click += (s, e) =>
            {
                GameSeconds = (int)nudSeconds.Value;
                Difficulty = (DifficultyLevel)cbDifficulty.SelectedIndex;
                SelectedBackground = cbBackground.SelectedItem.ToString();  // Seçilen arka plan
            };
        }
    }
}
