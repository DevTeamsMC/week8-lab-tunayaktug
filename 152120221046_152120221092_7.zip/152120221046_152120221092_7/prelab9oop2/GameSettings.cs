﻿namespace prelab9oop2
{
    public static class GameSettings
    {
        
        public static int GameDuration { get; set; } = 20;
        public static string Difficulty { get; set; } = "Kolay";   
        public static string ImageSet { get; set; } = "man";    
    }
}
