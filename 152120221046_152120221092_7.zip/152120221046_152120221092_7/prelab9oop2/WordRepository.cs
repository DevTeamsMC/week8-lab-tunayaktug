﻿// WordRepository.cs
using System.Collections.Generic;
using System.Linq;

namespace prelab9oop2
{
    public static class WordRepository
    {
        private static readonly Dictionary<Category, List<WordItem>> _allWords =
            new Dictionary<Category, List<WordItem>>()
        {
        // 20 Tarih kelimesi
        { Category.Tarih, new List<WordItem>()
            {
                new WordItem { Word = "atilla",       Clue = "Hun İmparatorluğu'nun ünlü hükümdarı" },
                new WordItem { Word = "osmanli",      Clue = "14. yüzyılda kurulan imparatorluk" },
                new WordItem { Word = "selcuklu",     Clue = "11. yüzyılda Anadolu'da hüküm süren devlet" },
                new WordItem { Word = "cumhuriyet",   Clue = "1923'te ilan edilen devlet biçimi" },
                new WordItem { Word = "mesrutiyet",   Clue = "Padişahın yetkilerini sınırlayan yönetim şekli" },
                new WordItem { Word = "hurriyet",     Clue = "Özgürlük anlamına gelen kavram" },
                new WordItem { Word = "istiklal",     Clue = "Bağımsızlık anlamına gelen kelime" },
                new WordItem { Word = "tanzimat",     Clue = "19. yüzyılda Osmanlı'da yapılan yenileşme hareketi" },
                new WordItem { Word = "lozan",        Clue = "1923'te imzalanan barış antlaşması" },
                new WordItem { Word = "fetih",        Clue = "Bir bölgeyi ele geçirme eylemi" },
                new WordItem { Word = "sevr",         Clue = "1920'de imzalanan antlaşma" },
                new WordItem { Word = "milli",        Clue = "Ulusal, ülkeye ait anlamında" },
                new WordItem { Word = "zafer",        Clue = "Galibiyet anlamına gelir" },
                new WordItem { Word = "klasik",       Clue = "Geçmişten günümüze süregelen tarz" },
                new WordItem { Word = "hilafet",      Clue = "İslam devletlerinde dini liderlik makamı" },
                new WordItem { Word = "kapitulasyon", Clue = "Avrupalı güçlere tanınan ayrıcalık" },
                new WordItem { Word = "mubadele",     Clue = "Nüfus değiş tokuşu" },
                new WordItem { Word = "istanbul",     Clue = "Bizans'ın başkenti" },
                new WordItem { Word = "ataturk",      Clue = "Modern Türkiye'nin kurucusu" },
                new WordItem { Word = "mektubat",     Clue = "Tarihi mektuplar koleksiyonu" }
            }
        },

        // 20 Coğrafya kelimesi
        { Category.Cografya, new List<WordItem>()
            {
                new WordItem { Word = "akdeniz",   Clue = "Türkiye'nin güneyindeki deniz" },
                new WordItem { Word = "marmara",   Clue = "Türkiye'nin kuzeybatısındaki deniz" },
                new WordItem { Word = "karadeniz", Clue = "Türkiye'nin kuzeyindeki deniz" },
                new WordItem { Word = "ege",       Clue = "Türkiye'nin batısındaki deniz" },
                new WordItem { Word = "anadolu",   Clue = "Türkiye'nin kara parçası" },
                new WordItem { Word = "istanbul",  Clue = "Türkiye'nin en kalabalık şehri" },
                new WordItem { Word = "ankara",    Clue = "Türkiye'nin başkenti" },
                new WordItem { Word = "izmir",     Clue = "Ege Bölgesi'nin liman kenti" },
                new WordItem { Word = "agri",      Clue = "Türkiye'nin en yüksek dağı" },
                new WordItem { Word = "ararat",    Clue = "Ağrı Dağı olarak da bilinir" },
                new WordItem { Word = "kapadokya", Clue = "Peri bacaları bölgesi" },
                new WordItem { Word = "pamukkale", Clue = "Beyaz traverten teraslarıyla ünlü" },
                new WordItem { Word = "bogazici",  Clue = "Boğaz çevresindeki yerleşim" },
                new WordItem { Word = "sinop",     Clue = "Karadeniz'deki kuzey şehri" },
                new WordItem { Word = "edirne",    Clue = "Trakya'da sınır kenti" },
                new WordItem { Word = "trabzon",   Clue = "Karadeniz sahilinde şehir" },
                new WordItem { Word = "alps",      Clue = "Avrupa'nın en yüksek dağları" },
                new WordItem { Word = "sahara",    Clue = "Dünyanın en büyük sıcak çölü" },
                new WordItem { Word = "amazon",    Clue = "Dünyanın en geniş nehir havzası" },
                new WordItem { Word = "himalaya",  Clue = "Dünyanın en yüksek dağ sırası" }
            }
        },

        // 20 Matematik kelimesi
        { Category.Matematik, new List<WordItem>()
            {
                new WordItem { Word = "bir",            Clue = "1 sayısını ifade eder" },
                new WordItem { Word = "iki",            Clue = "2 sayısını ifade eder" },
                new WordItem { Word = "uc",             Clue = "3 sayısını ifade eder" },
                new WordItem { Word = "dort",           Clue = "4 sayısını ifade eder" },
                new WordItem { Word = "bes",            Clue = "5 sayısını ifade eder" },
                new WordItem { Word = "alti",           Clue = "6 sayısını ifade eder" },
                new WordItem { Word = "carpim",         Clue = "Çarpma işlemine verilen ad" },
                new WordItem { Word = "bolum",          Clue = "Bölme işlemine verilen ad" },
                new WordItem { Word = "denklem",        Clue = "Eşitlik içeren matematiksel ifade" },
                new WordItem { Word = "integral",       Clue = "Türev işleminin ters işlemine verilen ad" },
                new WordItem { Word = "diferansiyel",   Clue = "Türev ile ilgili kavram" },
                new WordItem { Word = "geometri",       Clue = "Şekillerin özelliklerini inceleyen dal" },
                new WordItem { Word = "cebir",          Clue = "Denklem ve cebrik yapıların incelendiği alan" },
                new WordItem { Word = "matris",         Clue = "Sayıların düzenli tablosu" },
                new WordItem { Word = "vektor",         Clue = "Yön ve büyüklüğü olan nicelik" },
                new WordItem { Word = "fonksiyon",      Clue = "Girişe karşılık çıkan değer ilişkisi" },
                new WordItem { Word = "turev",          Clue = "Değişim hızını veren işlem" },
                new WordItem { Word = "permutasyon",    Clue = "Sıralama sayısı" },
                new WordItem { Word = "kombinasyon",    Clue = "Seçim sayısı" },
                new WordItem { Word = "asal",           Clue = "1 ve kendisinden başka böleni olmayan sayı" }
            }
        },

        // 20 Genel Kültür kelimesi
        { Category.GenelKültür, new List<WordItem>()
            {
                new WordItem { Word = "sanat",      Clue = "İnsan yaratıcılığının ifadesi" },
                new WordItem { Word = "kitap",      Clue = "Basılı veya dijital eser" },
                new WordItem { Word = "film",       Clue = "Hareketli görüntü kaydı" },
                new WordItem { Word = "muzik",      Clue = "Sesler aracılığıyla yapılan sanat" },
                new WordItem { Word = "tiyatro",    Clue = "Sahne üzerinde oyun" },
                new WordItem { Word = "festival",   Clue = "Kutlama veya etkinlik dönemi" },
                new WordItem { Word = "ekonomi",    Clue = "Kaynakların üretim ve dağılımı" },
                new WordItem { Word = "psikoloji",  Clue = "Zihin ve davranış bilimi" },
                new WordItem { Word = "felsefe",    Clue = "Bilgi ve varlık sorgulayan disiplin" },
                new WordItem { Word = "mimari",     Clue = "Yapı tasarımı sanatı" },
                new WordItem { Word = "biyoloji",   Clue = "Canlıları inceleyen bilim" },
                new WordItem { Word = "edebiyat",   Clue = "Yazılı ve sözlü anlatılar" },
                new WordItem { Word = "fotograf",   Clue = "Görüntü yakalama sanatı" },
                new WordItem { Word = "teknoloji",  Clue = "Bilimsel bilgi uygulamaları" },
                new WordItem { Word = "turizm",     Clue = "Seyahat ve gezi etkinlikleri" },
                new WordItem { Word = "spor",       Clue = "Fiziksel etkinlik ve oyunlar" },
                new WordItem { Word = "medya",      Clue = "Haber ve içerik iletişim araçları" },
                new WordItem { Word = "sinema",     Clue = "Film gösterim sanat dalı" },
                new WordItem { Word = "gazete",     Clue = "Günlük basılı yayın" },
                new WordItem { Word = "televizyon", Clue = "Görüntü ve ses yayın aracı" }
            }
        },

        // 20 Karma (karışık) kelime
        { Category.Karma, new List<WordItem>()
            {
                new WordItem { Word = "masa",        Clue = "Üzerine eşya konulan mobilya" },
                new WordItem { Word = "sandalye",    Clue = "Oturmak için mobilya" },
                new WordItem { Word = "araba",       Clue = "Karada yolcu taşıyan araç" },
                new WordItem { Word = "telefon",     Clue = "Sesli iletişim aracı" },
                new WordItem { Word = "bilgisayar",  Clue = "Elektronik hesaplama cihazı" },
                new WordItem { Word = "internet",    Clue = "Dünya çapında bilgisayar ağı" },
                new WordItem { Word = "kutuphane",   Clue = "Kitap ve kaynakların toplandığı yer" },
                new WordItem { Word = "ogrenci",     Clue = "Öğrenim gören kişi" },
                new WordItem { Word = "ogretmen",    Clue = "Ders veren eğitimci" },
                new WordItem { Word = "resim",       Clue = "Görsel sanat eseri" },
                new WordItem { Word = "uygulama",    Clue = "Yazılım programı" },
                new WordItem { Word = "makine",      Clue = "İş yapan araç veya cihaz" },
                new WordItem { Word = "ozellik",     Clue = "Nitelik ya da karakteristik" },
                new WordItem { Word = "deney",       Clue = "Bilimsel araştırma yöntemi" },
                new WordItem { Word = "proje",       Clue = "Planlı çalışma tasarımı" },
                new WordItem { Word = "fikir",       Clue = "Düşünce ya da tasavvur" },
                new WordItem { Word = "kedi",        Clue = "Evcil küçük memeli hayvan" },
                new WordItem { Word = "kopek",       Clue = "Sadık evcil hayvan" },
                new WordItem { Word = "bulut",       Clue = "Gökyüzündeki su buharı" },
                new WordItem { Word = "yildiz",      Clue = "Gece gökyüzündeki parlak cisim" }
            }
        }
        };

        public static List<WordItem> GetWords(Category category, DifficultyLevel diff)
        {
            List<WordItem> list;
            if (!_allWords.TryGetValue(category, out list))
                list = new List<WordItem>();

            switch (diff)
            {
                case DifficultyLevel.Kolay:
                    return list.Where(w => w.Word.Length <= 5).ToList();
                case DifficultyLevel.Orta:
                    return list.Where(w => w.Word.Length > 5 && w.Word.Length <= 8).ToList();
                case DifficultyLevel.Zor:
                    return list.Where(w => w.Word.Length > 8).ToList();
                default:
                    return new List<WordItem>(list);
            }
        }
    }
}
