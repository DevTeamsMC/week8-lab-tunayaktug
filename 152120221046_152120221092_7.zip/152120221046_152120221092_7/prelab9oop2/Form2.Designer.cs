﻿namespace prelab9oop2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btnGuess = new System.Windows.Forms.Button();
            this.btnEndGame = new System.Windows.Forms.Button();
            this.lblWord = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.lblWrongLetters = new System.Windows.Forms.Label();
            this.txtGuess = new System.Windows.Forms.TextBox();
            this.pbHangman = new System.Windows.Forms.PictureBox();
            this.lblButtonClue = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblDifficulty = new System.Windows.Forms.Label();
            this.lblTheme = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbHangman)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGuess
            // 
            this.btnGuess.Location = new System.Drawing.Point(403, 577);
            this.btnGuess.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(213, 80);
            this.btnGuess.TabIndex = 0;
            this.btnGuess.Text = "Tahmin et";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // btnEndGame
            // 
            this.btnEndGame.Location = new System.Drawing.Point(648, 577);
            this.btnEndGame.Margin = new System.Windows.Forms.Padding(4);
            this.btnEndGame.Name = "btnEndGame";
            this.btnEndGame.Size = new System.Drawing.Size(213, 80);
            this.btnEndGame.TabIndex = 1;
            this.btnEndGame.Text = "Oyunu bitir";
            this.btnEndGame.UseVisualStyleBackColor = true;
            this.btnEndGame.Click += new System.EventHandler(this.btnEndGame_Click);
            // 
            // lblWord
            // 
            this.lblWord.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblWord.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblWord.Location = new System.Drawing.Point(24, 39);
            this.lblWord.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWord.Name = "lblWord";
            this.lblWord.Size = new System.Drawing.Size(837, 87);
            this.lblWord.TabIndex = 2;
            this.lblWord.Text = "lblWord";
            this.lblWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScore
            // 
            this.lblScore.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblScore.Location = new System.Drawing.Point(9, 558);
            this.lblScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(245, 39);
            this.lblScore.TabIndex = 3;
            this.lblScore.Text = "lblScore";
            this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLength
            // 
            this.lblLength.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLength.Location = new System.Drawing.Point(4, 388);
            this.lblLength.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(843, 39);
            this.lblLength.TabIndex = 4;
            this.lblLength.Text = "lblLength";
            this.lblLength.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblWrongLetters
            // 
            this.lblWrongLetters.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblWrongLetters.Location = new System.Drawing.Point(4, 427);
            this.lblWrongLetters.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWrongLetters.Name = "lblWrongLetters";
            this.lblWrongLetters.Size = new System.Drawing.Size(843, 39);
            this.lblWrongLetters.TabIndex = 6;
            this.lblWrongLetters.Text = "lblWrongLetters";
            this.lblWrongLetters.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGuess
            // 
            this.txtGuess.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGuess.Location = new System.Drawing.Point(9, 601);
            this.txtGuess.Margin = new System.Windows.Forms.Padding(4);
            this.txtGuess.Multiline = true;
            this.txtGuess.Name = "txtGuess";
            this.txtGuess.Size = new System.Drawing.Size(117, 57);
            this.txtGuess.TabIndex = 7;
            // 
            // pbHangman
            // 
            this.pbHangman.BackColor = System.Drawing.Color.Gainsboro;
            this.pbHangman.Location = new System.Drawing.Point(25, 39);
            this.pbHangman.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbHangman.Name = "pbHangman";
            this.pbHangman.Size = new System.Drawing.Size(679, 732);
            this.pbHangman.TabIndex = 8;
            this.pbHangman.TabStop = false;
            // 
            // lblButtonClue
            // 
            this.lblButtonClue.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblButtonClue.Location = new System.Drawing.Point(760, 146);
            this.lblButtonClue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lblButtonClue.Name = "lblButtonClue";
            this.lblButtonClue.Size = new System.Drawing.Size(101, 38);
            this.lblButtonClue.TabIndex = 9;
            this.lblButtonClue.Text = "İpucu?";
            this.lblButtonClue.UseVisualStyleBackColor = true;
            this.lblButtonClue.Click += new System.EventHandler(this.lblButtonClue_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(791, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 47);
            this.label1.TabIndex = 10;
            this.label1.Text = "HANGMAN";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(9, 725);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(327, 39);
            this.label2.TabIndex = 11;
            this.label2.Text = "label2";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblTheme);
            this.panel1.Controls.Add(this.lblDifficulty);
            this.panel1.Controls.Add(this.lblCategory);
            this.panel1.Controls.Add(this.lblWord);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblButtonClue);
            this.panel1.Controls.Add(this.lblLength);
            this.panel1.Controls.Add(this.lblWrongLetters);
            this.panel1.Controls.Add(this.btnEndGame);
            this.panel1.Controls.Add(this.txtGuess);
            this.panel1.Controls.Add(this.btnGuess);
            this.panel1.Controls.Add(this.lblScore);
            this.panel1.Location = new System.Drawing.Point(13, 73);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 820);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.pbHangman);
            this.panel2.Location = new System.Drawing.Point(915, 73);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(733, 820);
            this.panel2.TabIndex = 13;
            // 
            // lblCategory
            // 
            this.lblCategory.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCategory.Location = new System.Drawing.Point(10, 776);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(260, 23);
            this.lblCategory.TabIndex = 12;
            this.lblCategory.Text = "label3";
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDifficulty.Location = new System.Drawing.Point(302, 776);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(252, 23);
            this.lblDifficulty.TabIndex = 13;
            this.lblDifficulty.Text = "label3";
            // 
            // lblTheme
            // 
            this.lblTheme.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTheme.Location = new System.Drawing.Point(570, 776);
            this.lblTheme.Name = "lblTheme";
            this.lblTheme.Size = new System.Drawing.Size(224, 23);
            this.lblTheme.TabIndex = 14;
            this.lblTheme.Text = "lblTheme";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1659, 1055);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbHangman)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Button btnEndGame;
        private System.Windows.Forms.Label lblWord;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblLength;
        private System.Windows.Forms.Label lblWrongLetters;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.PictureBox pbHangman;
        private System.Windows.Forms.Button lblButtonClue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblDifficulty;
        private System.Windows.Forms.Label lblTheme;
    }
}