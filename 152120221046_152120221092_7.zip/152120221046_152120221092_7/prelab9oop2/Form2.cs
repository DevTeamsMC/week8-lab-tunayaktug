﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace prelab9oop2
{
    public partial class Form2 : Form
    {
        private const int PanelSpacing = 20;
        private int _seconds;
        private DifficultyLevel _difficulty;
        private Category _category;
        private readonly string _bgPrefix;
        private Timer guessTimer = new Timer();
        private int timeLeft;
        private HashSet<char> guessedLetters = new HashSet<char>();
        private Dictionary<string, string> clues = new Dictionary<string, string>();

        private string selectedWord;
        private string displayWord;
        private int score;
        private int wrongGuesses;

        public Form2(int seconds, DifficultyLevel difficulty, Category category, string backgroundPrefix)
        {
            InitializeComponent();

            lblCategory.Text = $"Kategori:{_category}";
            lblDifficulty.Text = $"Zorluk:{_difficulty}";
            lblTheme.Text = $"Tema:{_bgPrefix}";

            // 1) Form’u tam ekran (maksimize) yap
            this.WindowState = FormWindowState.Maximized;
            // Eğer başlık çubuğu+kenarlıkları da tamamen kaldırmak istersen:
            // this.FormBorderStyle = FormBorderStyle.None;

            // 2) Panel’lerin designer’dan gelen Anchor ayarlarını kapat
            panel1.Anchor = AnchorStyles.None;
            panel2.Anchor = AnchorStyles.None;

            // 3) İlk konumlandırmayı hemen yap ve Resize olayına bağla
            CenterPanels();
            this.Resize += (s, e) => CenterPanels();

            
            // 4) Oyunu başlat
            _seconds = seconds;
            _difficulty = difficulty;
            _category = category;
            _bgPrefix = backgroundPrefix.ToLower();
            StartGame();
        }

        /// <summary>
        /// panel1 ile panel2'yi formun ortasına yatayda yan yana, dikeyde kendi yüksekliklerine göre ortalayarak koyar.
        /// </summary>
        private void CenterPanels()
        {
            // Form'un iç çalışma alanı
            int cw = this.ClientSize.Width;
            int ch = this.ClientSize.Height;

            // Toplam yan yana kapladıkları genişlik
            int totalWidth = panel1.Width + PanelSpacing + panel2.Width;

            // Başlangıç X koordinatı (ortalanmış)
            int startX = (cw - totalWidth) / 2;

            // Her panelin kendi yüksekliğine göre ortalanmış Y'si
            int y1 = (ch - panel1.Height) / 2;
            int y2 = (ch - panel2.Height) / 2;

            panel1.Location = new Point(startX, y1);
            panel2.Location = new Point(startX + panel1.Width + PanelSpacing, y2);
        }


        private void StartGame()
        {
            // 1) Repository’den kategori+zorluk filtresiyle havuzu al
            List<WordItem> pool = WordRepository.GetWords(_category, _difficulty);
            if (pool.Count == 0)
            {
                MessageBox.Show("Bu kategoride bu zorlukta kelime bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ReturnToMenu();
                return;
            }

            // 2) Rastgele bir WordItem seç
            var rnd = new Random();
            WordItem item = pool[rnd.Next(pool.Count)];
            selectedWord = item.Word;
            clues.Clear();
            clues[selectedWord] = item.Clue;

            // 3) Oyun değişkenlerini başlat
            displayWord = new string('_', selectedWord.Length);
            wrongGuesses = 0;
            score = 100;
            guessedLetters.Clear();
            timeLeft = _seconds;

            // 4) Zamanlayıcı
            label2.Text = $"Kalan Süre: {timeLeft} sn";
            guessTimer.Interval = 1000;
            guessTimer.Tick -= GuessTimer_Tick;
            guessTimer.Tick += GuessTimer_Tick;
            guessTimer.Start();

            // 5) Ekranı güncelle
            lblWord.Text = string.Join(" ", displayWord.ToCharArray());
            lblLength.Text = $"Kelime Uzunluğu: {selectedWord.Length}";
            lblWrongLetters.Text = "Yanlış Tahminler: ";
            lblScore.Text = $"PUAN: {score} P";

            
            // İpucu butonu stili
            lblButtonClue.MouseEnter += (s, e) => lblButtonClue.BackColor = Color.DarkOrange;
            lblButtonClue.MouseLeave += (s, e) => lblButtonClue.BackColor = Color.Orange;
            lblButtonClue.BackColor = Color.Orange;
            lblButtonClue.Size = new Size(80, 30);
            lblButtonClue.FlatStyle = FlatStyle.Flat;
            lblButtonClue.FlatAppearance.BorderSize = 0;
            lblButtonClue.Cursor = Cursors.Hand;

            // Tahmin butonu stili
            btnGuess.Text = "Tahmin Et";
            btnGuess.Font = new Font("Arial", 12, FontStyle.Bold);
            btnGuess.BackColor = Color.FromArgb(76, 175, 80);
            btnGuess.ForeColor = Color.White;
            btnGuess.FlatStyle = FlatStyle.Flat;
            btnGuess.FlatAppearance.BorderSize = 0;
            btnGuess.Cursor = Cursors.Hand;
            btnGuess.MouseEnter += (s, e) => btnGuess.BackColor = Color.DarkGreen;
            btnGuess.MouseLeave += (s, e) => btnGuess.BackColor = Color.FromArgb(76, 175, 80);

            // Oyunu bitir butonu stili
            btnEndGame.Text = "Oyunu Bitir";
            btnEndGame.Font = new Font("Arial", 12, FontStyle.Bold);
            btnEndGame.BackColor = Color.Gold;
            btnEndGame.ForeColor = Color.Black;
            btnEndGame.FlatStyle = FlatStyle.Flat;
            btnEndGame.FlatAppearance.BorderSize = 0;
            btnEndGame.Cursor = Cursors.Hand;
            btnEndGame.MouseEnter += (s, e) => btnEndGame.BackColor = Color.DarkOrange;
            btnEndGame.MouseLeave += (s, e) => btnEndGame.BackColor = Color.Gold;

            // Form arka plan rengi
            this.BackColor = Color.LightGray;

            // Başlangıç resmi
            var startImage = Path.Combine(
            Application.StartupPath,
            "images",
            $"{_bgPrefix}-01.jpg");   // artık man-01 değil
            if (File.Exists(startImage))
            {
                pbHangman.Image = Image.FromFile(startImage);
                pbHangman.SizeMode = PictureBoxSizeMode.StretchImage;
            }

            var catLabel = new Label
            {
                Name = "lblCategory",
                AutoSize = true,
                Location = new Point(20, 20),      // adjust as needed
                Font = new Font("Arial", 10, FontStyle.Bold),
                Text = $"Kategori: {_category}"
            };
            panel1.Controls.Add(catLabel);

            var diffLabel = new Label
            {
                Name = "lblDifficulty",
                AutoSize = true,
                Location = new Point(20, 45),      // just below the first
                Font = new Font("Arial", 10, FontStyle.Bold),
                Text = $"Zorluk:    {_difficulty}"
            };
            panel1.Controls.Add(diffLabel);

            // --- then your existing setup ...
            lblLength.Text = $"Kelime Uzunluğu: {selectedWord.Length}";
        }

        private void GuessTimer_Tick(object sender, EventArgs e)
        {
            timeLeft--;
            label2.Text = $"Kalan Süre: {timeLeft} sn";
            if (timeLeft <= 0)
            {
                guessTimer.Stop();
                this.BackColor = Color.Red;
                MessageBox.Show("Süre doldu! Kaybettiniz!", "Zaman Bitti", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ReturnToMenu();
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            if (txtGuess.Text.Length != 1 || !char.IsLetter(txtGuess.Text[0]))
            {
                MessageBox.Show("Lütfen sadece bir harf girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtGuess.Clear();
                return;
            }

            char g = char.ToLower(txtGuess.Text[0]);
            txtGuess.Clear();

            if (guessedLetters.Contains(g))
            {
                MessageBox.Show("Bu harfi zaten tahmin ettiniz.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            guessedLetters.Add(g);
            if (selectedWord.Contains(g))
            {
                // doğru tahmin
                var arr = displayWord.ToCharArray();
                for (int i = 0; i < selectedWord.Length; i++)
                    if (selectedWord[i] == g) arr[i] = g;
                displayWord = new string(arr);
                lblWord.Text = string.Join(" ", displayWord.ToCharArray());

                if (!displayWord.Contains('_'))
                {
                    guessTimer.Stop();
                    this.BackColor = Color.LightGreen;
                    panel1.BackColor = Color.LightGreen;
                    panel2.BackColor = Color.LightGreen;
                    MessageBox.Show("Tebrikler! Kazandınız!");
                    ReturnToMenu();
                }
            }
            else
            {
                // yanlış tahmin
                wrongGuesses++;
                score -= 10;
                lblScore.Text = $"PUAN: {score} P";
                lblWrongLetters.Text += g + ", ";

                var imgPath = Path.Combine(
                Application.StartupPath,
                "images",
                $"{_bgPrefix}-{(wrongGuesses + 1):D2}.jpg");
                if (File.Exists(imgPath))
                    pbHangman.Image = Image.FromFile(imgPath);

                if (wrongGuesses >= 10)
                {
                    guessTimer.Stop();
                    // 2) Form ve panellerin arkaplanını kırmızı yap
                    this.BackColor = Color.IndianRed;
                    panel1.BackColor = Color.IndianRed;
                    panel2.BackColor = Color.IndianRed;
                    MessageBox.Show($"Kaybettiniz! Doğru kelime: {selectedWord}");
                    ReturnToMenu();
                }
            }
        }

        private void lblButtonClue_Click(object sender, EventArgs e)
        {
            MessageBox.Show(clues[selectedWord], "İpucu");
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Oyunu bitirmek istiyor musunuz?", "Uyarı", MessageBoxButtons.YesNo) == DialogResult.Yes)
                ReturnToMenu();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            guessTimer.Stop();
        }

        private void ReturnToMenu()
        {
            new Form1().Show();
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lblCategory.Text = $"Kategori:{_category}";
            lblDifficulty.Text = $"Zorluk:{_difficulty}";
            lblTheme.Text = $"Tema:{_bgPrefix}";

        }
    }
}
