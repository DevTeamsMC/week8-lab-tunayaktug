﻿using prelab9oop2.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prelab9oop2
{
    public partial class Form1 : Form
    {

        private int _gameSeconds = 60;                           
        private DifficultyLevel _difficulty = DifficultyLevel.Kolay;
        private Category _category = Category.GenelKültür;
        private string _backgroundPrefix = "Adam";

        public Form1()
        {
            InitializeComponent();
         
            string imagePath = Path.Combine(Application.StartupPath, "images", "cover2.jpg");
            this.BackgroundImage = Image.FromFile(imagePath);
            this.BackgroundImageLayout = ImageLayout.Stretch;

        
            Label title = new Label();
            title.Text = "HANGMAN";
            title.Font = new Font("Arial", 32, FontStyle.Bold);
            title.ForeColor = Color.Black;
            title.BackColor = Color.Transparent;
            title.AutoSize = true;
            title.Location = new Point(this.Width / 2 - 130, this.Height / 2 - 150);
            title.Anchor = AnchorStyles.None;

            button1.Text = "BAŞLA";
            button1.Font = new Font("Arial", 14, FontStyle.Bold);
            button1.Size = new Size(120, 50);
            button1.Location = new Point(this.Width / 2 - 60, this.Height / 2 - 50);

           
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            button1.BackColor = Color.Orange;
            button1.ForeColor = Color.Black;
            button1.MouseEnter += (s, e) => button1.BackColor = Color.DarkOrange;
            button1.MouseLeave += (s, e) => button1.BackColor = Color.Orange;


            Button settingsButton = new Button();
           
          
            settingsButton.Size = new Size(100, 40);
            settingsButton.Location = new Point(20, 20); // istediğiniz konuma ayarlayın
            settingsButton.Click += SettingsButton_Click;
            this.Controls.Add(settingsButton);

            settingsButton.Text = "AYARLAR";
            settingsButton.Font = new Font("Arial", 14, FontStyle.Bold);
            settingsButton.Size = new Size(120, 50);
         


            settingsButton.FlatStyle = FlatStyle.Flat;
            settingsButton.FlatAppearance.BorderSize = 0;
            settingsButton.BackColor = Color.Orange;
            settingsButton.ForeColor = Color.Black;
            settingsButton.MouseEnter += (s, e) => settingsButton.BackColor = Color.DarkOrange;
            settingsButton.MouseLeave += (s, e) => settingsButton.BackColor = Color.Orange;

            cbCategory.Items.AddRange(Enum.GetNames(typeof(Category)));
            cbCategory.SelectedItem = _category.ToString();
            this.Controls.Add(cbCategory);


            

            this.Controls.Add(title);
            this.WindowState = FormWindowState.Maximized;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cbCategory.SelectedItem == null)
            {
                MessageBox.Show("Lütfen bir kategori seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _category = (Category)Enum.Parse(typeof(Category), cbCategory.SelectedItem.ToString());
           

            var gameForm = new Form2(_gameSeconds, _difficulty, _category, _backgroundPrefix);
            gameForm.Show();
            this.Hide();
        }
    

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            using (var settingsForm = new SettingsForm(_gameSeconds, _difficulty))
            {
                if (settingsForm.ShowDialog() == DialogResult.OK)
                {
                    _gameSeconds = settingsForm.GameSeconds;
                    _difficulty = settingsForm.Difficulty;
                    // Yeni: SelectedBackground alanını alıp sakla
                    _backgroundPrefix = settingsForm.SelectedBackground.ToLower();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
